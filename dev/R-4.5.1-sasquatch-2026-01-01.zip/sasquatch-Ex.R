pkgname <- "sasquatch"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('sasquatch')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("configure_saspy")
### * configure_saspy

flush(stderr()); flush(stdout())

### Name: configure_saspy
### Title: Configure SASPy package
### Aliases: configure_saspy

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)

# set up an ODA connection
config_saspy(template = "oda")
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("install_saspy")
### * install_saspy

flush(stderr()); flush(stdout())

### Name: install_saspy
### Title: Install SASPy package
### Aliases: install_saspy

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
install_saspy(
  envname = "new-sasquatch-env",
  extra_packages = c("matplotlib", "numpy"),
)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_connect")
### * sas_connect

flush(stderr()); flush(stdout())

### Name: sas_connect
### Title: Establish SAS session
### Aliases: sas_connect

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect(cfgname = "oda")
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_disconnect")
### * sas_disconnect

flush(stderr()); flush(stdout())

### Name: sas_disconnect
### Title: Disconnect SAS session
### Aliases: sas_disconnect

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

sas_disconnect()
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_engine")
### * sas_engine

flush(stderr()); flush(stdout())

### Name: sas_engine
### Title: A SAS engine for 'knitr'
### Aliases: sas_engine

### ** Examples

# The below function is run internally within `sasquatch` on startup
knitr::knit_engines$set(sas = sas_engine)



cleanEx()
nameEx("sas_file_copy")
### * sas_file_copy

flush(stderr()); flush(stdout())

### Name: sas_file_copy
### Title: Copy a file on SAS
### Aliases: sas_file_copy

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
# connect to SAS
sas_connect()

# create an example file
local_path <- tempfile(fileext = ".txt")
cat("some example text", file = tempfile_path)

sas_path <- readline(
  "Please provide the full path to upload an example file to (e.g., ~/example.txt)."
)
sas_file_upload(local_path, sas_path)

from_path <- sas_path
to_path <- readline(
  "Please provide the full path to copy the example file to (e.g., ~/example_copy.txt)."
)
sas_file_copy(from_path, to_path)

# cleanup
unlink(local_path)
sas_file_remove(from_path)
sas_file_remove(to_path)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_file_download")
### * sas_file_download

flush(stderr()); flush(stdout())

### Name: sas_file_download
### Title: Download a file from SAS
### Aliases: sas_file_download

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
# connect to SAS
sas_connect()

# create an example file
local_path <- tempfile(fileext = ".txt")
cat("some example text", file = tempfile_path)

sas_path <- readline(
  "Please provide the full path to upload an example file to (e.g., ~/example.txt)."
)
sas_file_upload(local_path, sas_path)

# download the uploaded file
local_copy_path <- sub("\\.txt$", "_copy.txt", tempfile_path)
sas_file_download(sas_path, local_copy_path)

# cleanup
unlink(local_path)
unlink(local_copy_path)
sas_file_remove(sas_path)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_file_exists")
### * sas_file_exists

flush(stderr()); flush(stdout())

### Name: sas_file_exists
### Title: Check if file on SAS exists
### Aliases: sas_file_exists

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
# connect to SAS
sas_connect()

# create an example file
local_path <- tempfile(fileext = ".txt")
cat("some example text", file = tempfile_path)

sas_path <- readline(
  "Please provide the full path to upload an example file to (e.g., ~/example.txt)."
)
sas_file_upload(local_path, sas_path)

sas_file_exists(sas_path)

# cleanup
unlink(local_path)
sas_file_remove(sas_path)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_file_remove")
### * sas_file_remove

flush(stderr()); flush(stdout())

### Name: sas_file_remove
### Title: Delete a file or directory from SAS
### Aliases: sas_file_remove

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
# connect to SAS
sas_connect()

# create an example file
local_path <- tempfile(fileext = ".txt")
cat("some example text", file = tempfile_path)

sas_path <- readline(
  "Please provide the full path to upload an example file to (e.g., ~/example.txt)."
)
sas_file_upload(local_path, sas_path)

sas_file_remove(sas_path)

# cleanup
unlink(local_path)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_file_upload")
### * sas_file_upload

flush(stderr()); flush(stdout())

### Name: sas_file_upload
### Title: Upload a file to SAS
### Aliases: sas_file_upload

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
# connect to SAS
sas_connect()

# create an example file
local_path <- tempfile(fileext = ".txt")
cat("some example text", file = tempfile_path)

sas_path <- readline(
  "Please provide the full path to upload an example file to (e.g., ~/example.txt)."
)
sas_file_upload(local_path, sas_path)

# cleanup
unlink(local_path)
sas_file_remove(sas_path)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_from_r")
### * sas_from_r

flush(stderr()); flush(stdout())

### Name: sas_from_r
### Title: Convert R table to SAS
### Aliases: sas_from_r

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

sas_from_r(mtcars, "mtcars")
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_get_session")
### * sas_get_session

flush(stderr()); flush(stdout())

### Name: sas_get_session
### Title: Get current SAS session
### Aliases: sas_get_session

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

sas_get_session()
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_list")
### * sas_list

flush(stderr()); flush(stdout())

### Name: sas_list
### Title: List contents of a SAS directory
### Aliases: sas_list

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

sas_list(".")
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_run_file")
### * sas_run_file

flush(stderr()); flush(stdout())

### Name: sas_run_file
### Title: Execute SAS file
### Aliases: sas_run_file

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

tempfile_sas_path <- tempfile(fileext = ".sas")
tempfile_html_path <- sub("\\.sas$", ".html", tempfile_sas_path)
tempfile_log_path <- sub("\\.sas$", ".log", tempfile_sas_path)
cat("PROC MEANS DATA = sashelp.cars;RUN;", file = tempfile_sas_path)
sas_run_file(tempfile_sas_path, tempfile_html_path)

# clean up
unlink(tempfile_sas_path)
unlink(tempfile_html_path)
unlink(tempfile_log_path)
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_run_selected")
### * sas_run_selected

flush(stderr()); flush(stdout())

### Name: sas_run_selected
### Title: Execute selected SAS code
### Aliases: sas_run_selected

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

# highlight something in the active editor of RStudio or Positron

sas_run_selected()
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_run_string")
### * sas_run_string

flush(stderr()); flush(stdout())

### Name: sas_run_string
### Title: Execute SAS code string
### Aliases: sas_run_string

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

sas_run_string("PROC MEANS DATA = sashelp.cars;RUN;")
## Don't show: 
}) # examplesIf
## End(Don't show)



cleanEx()
nameEx("sas_to_r")
### * sas_to_r

flush(stderr()); flush(stdout())

### Name: sas_to_r
### Title: Convert SAS table to R
### Aliases: sas_to_r

### ** Examples

## Don't show: 
if (interactive()) withAutoprint({ # examplesIf
## End(Don't show)
sas_connect()

cars <- sas_to_r("cars", "sashelp")
## Don't show: 
}) # examplesIf
## End(Don't show)



### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
