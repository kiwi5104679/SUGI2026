pkgname <- "SASmarkdown"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('SASmarkdown')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("find_sas")
### * find_sas

flush(stderr()); flush(stdout())

### Name: find_sas
### Title: A helper function that seeks to locate your SAS executable.
### Aliases: find_sas

### ** Examples

indoc <- '
---
title: "Basic SASmarkdown Doc"
author: "Doug Hemken"
output: html_document
---
# An R console example
## In a first code chunk, set up with
```{r}
library(SASmarkdown)
```
## Then mark SAS code chunks with
```{sas}
data class;
  set sashelp.class;
  bmi = 703*weight/height**2;
  run;
  
proc means;
  var bmi;
  run;
```
Some more document text here.
'

if (!is.null(SASmarkdown::find_sas())) {
  # To run this example, remove tempdir().
  fmd <- file.path(tempdir(), "test.md")
  fhtml <- file.path(tempdir(), "test.html")

  knitr::knit(text=indoc, output=fmd)
  rmarkdown::render(fmd, "html_document", fhtml)
}




cleanEx()
nameEx("sas_collectcode")
### * sas_collectcode

flush(stderr()); flush(stdout())

### Name: sas_collectcode
### Title: Create a knitr chunk hook for accumlating code.
### Aliases: sas_collectcode

### ** Examples

sas_collectcode()
## Not run: 
##D indoc <- '
##D ---
##D title: "Linking SASmarkdown Code Chunks"
##D author: "Doug Hemken"
##D output: html_document
##D ---
##D # An R console example
##D ## In a first code chunk, set up with
##D ```{r}
##D library(SASmarkdown)
##D ```
##D ## Then mark SAS code chunks with
##D ```{sas, collectcode=TRUE}
##D data class;
##D   set sashelp.class;
##D   bmi = 703*weight/height**2;
##D   run;
##D ```
##D 
##D ## A later chunk that depends on the first.
##D ```{sas}
##D proc means;
##D   var bmi;
##D   run;
##D ```
##D '
##D if (!is.null(SASmarkdown::find_sas())) {
##D   # To run this example, remove tempdir().
##D   fmd <- file.path(tempdir(), "test.md")
##D   fhtml <- file.path(tempdir(), "test.html")
##D 
##D   knitr::knit(text=indoc, output=fmd)
##D   rmarkdown::render(fmd, "html_document", fhtml)
##D }
## End(Not run)



cleanEx()
nameEx("sas_enginesetup")
### * sas_enginesetup

flush(stderr()); flush(stdout())

### Name: sas_enginesetup
### Title: Create SAS engines for knitr
### Aliases: sas_enginesetup sashtml saslog sashtmllog saspdf saspdflog

### ** Examples

sas_enginesetup(sashtml=sashtml, saslog=saslog)

indoc <- '
---
title: "Basic SASmarkdown Doc"
author: "Doug Hemken"
output: html_document
---
# In a first code chunk, set up with
```{r}
library(SASmarkdown)
```
# Then set up SAS code chunks with
```{sas}
proc means data=sashelp.class;
run;
```
'
if (!is.null(SASmarkdown::find_sas())) {
  # To run this example, remove tempdir().
  fmd <- file.path(tempdir(), "test.md")
  fhtml <- file.path(tempdir(), "test.html")

  knitr::knit(text=indoc, output=fmd)
  rmarkdown::render(fmd, "html_document", fhtml)
}




cleanEx()
nameEx("sas_output")
### * sas_output

flush(stderr()); flush(stdout())

### Name: sas_output
### Title: A function to provide cleaner output for knitr's SAS engines.
### Aliases: sas_output hook_orig

### ** Examples

## Not run: 
##D indoc <- '
##D ---
##D title: "Basic SASmarkdown Doc"
##D author: "Doug Hemken"
##D output: html_document
##D ---
##D # In a first code chunk, set up with
##D ```{r}
##D library(SASmarkdown)
##D ```
##D # Then set up SAS code chunks with
##D ```{sas}
##D proc means data=sashelp.class;
##D run;
##D ```
##D '
##D if (!is.null(SASmarkdown::find_sas())) {
##D   # To run this example, remove tempdir().
##D   fmd <- file.path(tempdir(), "test.md")
##D   fhtml <- file.path(tempdir(), "test.html")
##D 
##D   knitr::knit(text=indoc, output=fmd)
##D   rmarkdown::render(fmd, "html_document", fhtml)
##D }
## End(Not run)



cleanEx()
nameEx("saslog_hookset")
### * saslog_hookset

flush(stderr()); flush(stdout())

### Name: saslog_hookset
### Title: A function to clean SAS log files
### Aliases: saslog_hookset sasloghook

### ** Examples

# saslog_hookset() # called during loading

indoc <- '
---
title: "Basic SASmarkdown Doc"
author: "Doug Hemken"
output: html_document
---
# In a first code chunk, set up with
```{r}
library(SASmarkdown)
```
# Then set up SAS code chunks with
```{sas}
proc means data=sashelp.class;
run;
```
'
if (!is.null(SASmarkdown::find_sas())) {
  # To run this example, remove tempdir().
  fmd <- file.path(tempdir(), "test.md")
  fhtml <- file.path(tempdir(), "test.html")

  knitr::knit(text=indoc, output=fmd)
  rmarkdown::render(fmd, "html_document", fhtml)
}



cleanEx()
nameEx("spinsas")
### * spinsas

flush(stderr()); flush(stdout())

### Name: spinsas
### Title: Convert a specially marked up SAS file to Markdown and HTML.
### Aliases: spinsas

### ** Examples


## Not run: 
##D indoc <- '
##D ** # Native SASmarkdown
##D First, call the `SASmarkdown`` package in R.;
##D 
##D *R require(SASmarkdown);
##D 
##D ** Then execute some SAS code.  First specify the
##D chunk header, then the code.;
##D 
##D *+ example;
##D proc means data=sashelp.class;
##D run;
##D '
##D x<-spinsas(text=indoc)
##D writeLines(x, "indoc.html")
## End(Not run)



### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
